<?php

/**
 * Configuracion sitio, base de datos
 * @author Diego Saavedra
 * @created 25/12/2016
 * @copyright DG Solutions sas
 */
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "jcafutbol");
define('DB_CHARSET', 'utf-8');
